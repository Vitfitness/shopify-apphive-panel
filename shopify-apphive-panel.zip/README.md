
# Shopify + AppHive Panel

Este es el panel inteligente para gestionar productos, pedidos y sincronización entre Shopify y AppHive.
