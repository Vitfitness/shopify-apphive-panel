
export default function Home() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>🧠 Shopify + AppHive Panel</h1>
      <p>Panel en construcción. Aquí controlaremos inventario, usuarios y pedidos.</p>
    </div>
  );
}
